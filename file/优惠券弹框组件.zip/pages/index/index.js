//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    couponData:[
      { img: 'https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1591410693&di=f6fad12ad78794ea77d77a262e2a90ac&src=http://pic.qjimage.com/east017/high/east-ep-a31-6552726.jpg', name: '襄阳牛肉面', desc: '满减36可用', priceN: 8 },
      { img: 'https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1591410693&di=f6fad12ad78794ea77d77a262e2a90ac&src=http://pic.qjimage.com/east017/high/east-ep-a31-6552726.jpg', name: '襄阳牛肉面', desc: '满减36可用', priceN: 8 },
      { img: 'https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1591410693&di=f6fad12ad78794ea77d77a262e2a90ac&src=http://pic.qjimage.com/east017/high/east-ep-a31-6552726.jpg', name: '襄阳牛肉面', desc: '满减36可用', priceN: 8 },
      { img: 'https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1591410693&di=f6fad12ad78794ea77d77a262e2a90ac&src=http://pic.qjimage.com/east017/high/east-ep-a31-6552726.jpg', name: '襄阳牛肉面', desc: '满减36可用', priceN: 8 },
      { img: 'https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1591410693&di=f6fad12ad78794ea77d77a262e2a90ac&src=http://pic.qjimage.com/east017/high/east-ep-a31-6552726.jpg', name: '襄阳牛肉面', desc: '满减36可用', priceN: 8 },
      { img: 'https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1591410693&di=f6fad12ad78794ea77d77a262e2a90ac&src=http://pic.qjimage.com/east017/high/east-ep-a31-6552726.jpg', name: '襄阳牛肉面', desc: '满减36可用', priceN: 8 },
      { img: 'https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1591410693&di=f6fad12ad78794ea77d77a262e2a90ac&src=http://pic.qjimage.com/east017/high/east-ep-a31-6552726.jpg', name: '襄阳牛肉面', desc: '满减36可用', priceN: 8 },
    ]
  },
  onLoad(){}
})
