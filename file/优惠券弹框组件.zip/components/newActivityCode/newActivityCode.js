// components/newActivityCode/newActivityCode.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    hiddenState:{
      type:Boolean,
      value:true
    },
    couponData:{
      type:Object,
      value:''
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    closeNewActity(e){
      let that = this;
          that.setData({
            hiddenState: false
          })
    },
    preventTouchMove() {
      return false;
    },
  }
})
